kubeadm join 10.0.0.10:6443 --token 1qzq8d.g78j7js0pw7qobt3     --discovery-token-ca-cert-hash sha256:452314cb251f9026061c77bb22e7648cb96451b65f2e825a3b66907b3a3406aa 
